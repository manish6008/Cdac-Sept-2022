class P8{
public static void main(String[]args){
for(int i=5;i>=1;i--) //ROWS
{
	for(int j=i;j>1;j--) //SPACE
{
System.out.print(" ");
}

for(int j=i;j<=5;j++) //COLUMN
{
System.out.print(j+" ");
}
{
	System.out.println();
}
}
}
}